# minggu-02

# Penjelasan Tentang Tutorial Python pada bab - 4

- https://docs.python.org/3/tutorial/controlflow.html

	pada workshop ini kita membuat script python yang ada dalam masing - masing sub bab - 4
	
	1. if Statements
	   dimana pernyataan if digunakan untuk eksekusi bersyarat
	   
	2. for Statements
	
	3. range Function
	
	4. break and continue Statements, and else Clauses on Loops
	
	5. pass Statements
	
	6. Defining Functions
