# minggu-03

# Tutorial Struktur Data pada Bab - 5 https://docs.python.org/3/tutorial/datastructures.html

5.1 More on Lists

	5.1.1 Using Lists as Stacks
	5.1.2 Using Lists as Queues
	5.1.3 List Comprehensions
	5.1.4 Nested List Comprehensions
	
5.2 The del Statement

5.3 Tuples and Sequence

5.4 Sets

5.5 Dictionaries

5.6 Looping Techniques

5.7 More on Conditions

5.8 Comparing Sequences and Other Types